require.config({
	deps: [ 'init' ]
});
